# JARVIS Android APK Builder

Android WebView wrapper para sa JARVIS V2 prototype. Target: Infinix SMART 8 (X6525), Android 13, 4 GB RAM.

## Mahalagang limitasyon
- Hindi pa ito full offline generative AI. Basic offline commands lang ang available; online AI requires a compatible API endpoint and key.
- Experimental ang voice features. Android WebView/browser support varies; hindi guaranteed ang wake phrase at maaaring hindi gumana ang speech recognition.
- Ang workflow ay gagawa ng **debug APK**. Hindi ito Play Store release/signed production build.

## Paano makuha ang APK gamit ang cellphone
1. I-extract ang ZIP.
2. Gumawa ng GitHub account kung wala pa, at gumawa ng bagong repository.
3. I-upload ang laman ng extracted folder sa repository (dapat nasa root ang `settings.gradle`, `build.gradle`, `app/`, at `.github/`).
4. Sa repository, buksan ang **Actions** tab.
5. Piliin ang **Build JARVIS APK** at pindutin ang **Run workflow**. Kung hindi lumabas, siguraduhing nasa `main` branch ang files.
6. Kapag successful, buksan ang run at i-download ang artifact na **JARVIS-debug-APK**.
7. I-extract ang artifact ZIP, tap ang `app-debug.apk`, at sundin ang Android install prompt. Maaaring hingin ng Android ang pahintulot na mag-install mula sa browser/files app.

## Build gamit ang Android Studio sa computer
Buksan ang folder bilang Gradle project at patakbuhin ang `gradle assembleDebug` o gamitin ang Android Studio Build > Build APK(s).
