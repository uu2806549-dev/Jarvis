const $ = id => document.getElementById(id);
const chat = $("chat");
let endpoint = "", model = "", apiKey = "";
let voiceEnabled = true;
let wakeMode = false;
let recognition = null;
let listening = false;
let history = JSON.parse(localStorage.getItem("jarvis_history") || "[]");

const systemPrompt = "You are JARVIS, a helpful and respectful assistant. Default to natural Filipino/Tagalog. Detect the user's language and reply in that same language. Be concise, clear, and honest.";

function addMessage(text, who, save=true) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${who}`;
  const label = document.createElement("span");
  label.className = "who";
  label.textContent = who === "bot" ? "JARVIS" : "IKAW";
  const p = document.createElement("p");
  p.textContent = text;
  wrap.append(label, p);
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  if (save) {
    history.push({who, text});
    history = history.slice(-40);
    localStorage.setItem("jarvis_history", JSON.stringify(history));
  }
}
function renderHistory() {
  if (history.length) {
    chat.innerHTML = "";
    history.forEach(m => addMessage(m.text, m.who, false));
  }
}
function speechLanguage(text) {
  // Basic language hint for speech output. Full language understanding is handled by online AI.
  if (/[ก-๙]/.test(text)) return "th-TH";
  if (/[ぁ-んァ-ン]/.test(text)) return "ja-JP";
  if (/[一-龯]/.test(text)) return "zh-CN";
  if (/[А-Яа-яЁё]/.test(text)) return "ru-RU";
  if (/\b(the|hello|what|how|please|thanks|good morning)\b/i.test(text)) return "en-US";
  return "fil-PH";
}
function speak(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = speechLanguage(text);
  u.rate = 0.98;
  speechSynthesis.speak(u);
}
function offlineReply(raw) {
  const t = raw.toLowerCase().trim();
  if (/^(hi|hello|hey|kumusta|kamusta)\b/.test(t)) return "Kumusta! Ako si JARVIS. Handa akong tumulong.";
  if (t.includes("pangalan mo") || t.includes("who are you")) return "Ako si JARVIS, ang personal assistant mo.";
  if (t.includes("oras") || t.includes("time")) return "Ang oras sa device mo ay " + new Date().toLocaleTimeString([], {hour:"numeric",minute:"2-digit"}) + ".";
  if (t.includes("petsa") || t.includes("date") || t.includes("today")) return "Ang petsa ngayon ay " + new Date().toLocaleDateString("fil-PH", {dateStyle:"full"}) + ".";
  if (t.includes("battery") || t.includes("baterya")) return "Hindi lahat ng browser ay nagbibigay ng battery status. Tingnan ang battery icon ng Android mo.";
  if (t.includes("joke") || t.includes("biro")) return "Bakit mahusay magtago ang computer? Kasi marunong siyang mag-minimize. 😄";
  if (t.includes("salamat") || t.includes("thank you")) return "Walang anuman. Nandito ako para tumulong.";
  if (t.includes("clear chat") || t.includes("burahin ang usapan")) return "__CLEAR__";
  if (t.includes("help") || t.includes("tulong")) return "Offline kaya kong sabihin ang oras at petsa, magpakilala, at sumagot sa ilang basic na command. Para sa mas malawak na sagot, ikonekta ang online AI.";
  return "Naka-offline mode ako. Kaya ko ang basic commands, pero para sa mas malawak na kaalaman kailangan ko ng online AI o isang compatible local AI model.";
}
async function onlineReply(text) {
  const messages = [{role:"system", content:systemPrompt}];
  const recent = history.slice(-12);
  recent.forEach(m => messages.push({role:m.who === "user" ? "user" : "assistant", content:m.text}));
  messages.push({role:"user", content:text});
  const response = await fetch(endpoint, {
    method:"POST",
    headers:{"Content-Type":"application/json", "Authorization":`Bearer ${apiKey}`},
    body:JSON.stringify({model, messages, temperature:0.7})
  });
  if (!response.ok) throw new Error(`Online AI error (${response.status}). Tingnan ang endpoint, model, at API key.`);
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "Walang nabalik na sagot mula sa AI.";
}
async function handle(text) {
  text = text.trim();
  if (!text) return;
  addMessage(text, "user");
  $("status").textContent = navigator.onLine ? "PROCESSING" : "OFFLINE";
  let answer;
  if (endpoint && apiKey && model && navigator.onLine) {
    try { answer = await onlineReply(text); }
    catch (e) { answer = offlineReply(text) + "\n\nHindi makakonekta sa online AI: " + e.message; }
  } else answer = offlineReply(text);

  if (answer === "__CLEAR__") {
    history = [];
    localStorage.removeItem("jarvis_history");
    chat.innerHTML = "";
    answer = "Na-clear na ang chat history sa device na ito.";
  }
  addMessage(answer, "bot");
  speak(answer);
  $("status").textContent = endpoint && navigator.onLine ? "ONLINE / READY" : "OFFLINE READY";
}
$("composer").addEventListener("submit", async e => {
  e.preventDefault();
  const text = $("message").value.trim();
  $("message").value = "";
  await handle(text);
});
$("settingsBtn").onclick = () => $("settings").showModal();
$("saveSettings").onclick = () => {
  endpoint = $("endpoint").value.trim();
  model = $("model").value.trim();
  apiKey = $("apiKey").value.trim();
  $("settingsNote").textContent = endpoint && model && apiKey
    ? "Online connection set para sa session na ito. Huwag i-publish ang API key."
    : "Kumpletuhin ang endpoint, model, at API key.";
  $("settings").close();
  $("status").textContent = endpoint && apiKey && model ? "ONLINE READY" : "OFFLINE READY";
};
$("offlineOnly").onclick = () => {
  endpoint = ""; model = ""; apiKey = "";
  $("endpoint").value = ""; $("model").value = ""; $("apiKey").value = "";
  $("settings").close(); $("status").textContent = "OFFLINE READY";
};
$("voiceBtn").onclick = () => {
  voiceEnabled = !voiceEnabled;
  $("voiceBtn").textContent = voiceEnabled ? "🔊 VOICE ON" : "🔇 VOICE OFF";
  if (!voiceEnabled && "speechSynthesis" in window) speechSynthesis.cancel();
};
$("clearBtn").onclick = () => {
  history = []; localStorage.removeItem("jarvis_history"); chat.innerHTML = "";
  addMessage("Handa na ako sa bagong usapan.", "bot");
};
function startRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    addMessage("Hindi suportado ng browser ang voice recognition. Gamitin muna ang text input o subukan ang Chrome.", "bot");
    return;
  }
  if (recognition) { try { recognition.stop(); } catch (_) {} }
  recognition = new SR();
  recognition.lang = "fil-PH";
  recognition.interimResults = false;
  recognition.continuous = wakeMode;
  recognition.onstart = () => { listening = true; $("status").textContent = wakeMode ? "WAKE MODE" : "LISTENING"; };
  recognition.onerror = () => { listening = false; $("status").textContent = "READY"; };
  recognition.onend = () => {
    listening = false;
    if (wakeMode) setTimeout(() => { if (wakeMode) startRecognition(); }, 700);
    else $("status").textContent = endpoint ? "ONLINE READY" : "OFFLINE READY";
  };
  recognition.onresult = e => {
    const phrase = e.results[e.results.length - 1][0].transcript.trim();
    if (!wakeMode) { handle(phrase); return; }
    const lower = phrase.toLowerCase();
    const wake = ["hey jarvis", "jarvis", "hei jarvis"];
    const matched = wake.find(w => lower.includes(w));
    if (matched) {
      const command = phrase.slice(lower.indexOf(matched) + matched.length).trim();
      if (command) handle(command);
      else { speak("Nandito ako. Ano ang maitutulong ko?"); $("status").textContent = "SPEAK NOW"; }
    }
  };
  try { recognition.start(); } catch (_) {}
}
$("mic").onclick = () => { wakeMode = false; startRecognition(); };
const wakeButton = document.createElement("button");
wakeButton.className = "foot-btn";
wakeButton.textContent = "◉ WAKE OFF";
wakeButton.onclick = () => {
  wakeMode = !wakeMode;
  wakeButton.textContent = wakeMode ? "◉ WAKE ON" : "◉ WAKE OFF";
  if (wakeMode) {
    speak("Wake mode activated. Sabihin ang Hey JARVIS.");
    startRecognition();
  } else if (recognition) recognition.stop();
};
document.querySelector("footer").appendChild(wakeButton);
window.addEventListener("online", () => $("status").textContent = endpoint ? "ONLINE READY" : "OFFLINE READY");
window.addEventListener("offline", () => $("status").textContent = "OFFLINE READY");
renderHistory();
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
